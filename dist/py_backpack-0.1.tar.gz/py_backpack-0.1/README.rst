.. Lines starting with two dots are special commands. But if no command can be found, the line is considered as a comment

===========
py_backpack
===========

This repository aims at providing useful modules and code snippets that I use almost everyday.

.. Installation
.. =============
.. To install use:
..     `pip install <path to dist/*.whl>`
.. 
.. Modules
.. ==========
..
..
.. manipUtils.fmanip
.. -----------------
.. File manipulation functions for everyday use.
..
..
.. manipUtils.arraymanip
.. ----------------------
.. Array manipulation functions for everyday use.
..
..
.. manipUtils.figmanip
.. -----------------
.. Matplotlib figure manipulation functions for everyday use.
